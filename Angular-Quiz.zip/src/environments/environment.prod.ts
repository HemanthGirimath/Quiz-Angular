export const environment = {
  firebase: {
    projectId: 'angular-quiz-9c893',
    appId: '1:45118330632:web:5e91b4c1841c56b19cfebd',
    storageBucket: 'angular-quiz-9c893.appspot.com',
    apiKey: 'AIzaSyDuPlv7HxZTALxXLyWm_hq5w_bIiKQI13w',
    authDomain: 'angular-quiz-9c893.firebaseapp.com',
    messagingSenderId: '45118330632',
  },
  production: true
};
